const express = require('express');
const mysql = require('mysql');
const bodyParser = require('body-parser');
const bcrypt = require('bcryptjs');
const { body, validationResult } = require('express-validator');

const app = express();
app.use(bodyParser.urlencoded({ extended: false }));

// Database connection
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'Apollo123#',
    database: 'webapp'
});

db.connect((err) => {
    if (err) throw err;
    console.log('Connected to MySQL database');
});

// Serve static files (like CSS and client-side JS)
app.use(express.static(__dirname));

// Registration Route
app.post('/registration.php', 
    // Form validation using express-validator
    body('email').isEmail().withMessage('Enter a valid email address'),
    body('password').isLength({ min: 6 }).withMessage('Password must be at least 6 characters'),
    (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
    }

    const { name, email, password } = req.body;

    // Hash password
    bcrypt.hash(password, 10, (err, hash) => {
        if (err) throw err;

        // Insert into database
        const query = 'INSERT INTO users (name, email, password) VALUES (?, ?, ?)';
        db.query(query, [name, email, hash], (err, result) => {
            if (err) {
                return res.status(500).json({ error: 'Error inserting user data' });
            }
            res.send('User registered successfully!');
        });
    });
});

// Login Route
app.post('/login.php', (req, res) => {
    const { email, password } = req.body;

    const query = 'SELECT * FROM users WHERE email = ?';
    db.query(query, [email], (err, results) => {
        if (err) throw err;

        if (results.length === 0) {
            return res.status(400).send('User not found');
        }

        const user = results[0];

        // Compare password with hashed password
        bcrypt.compare(password, user.password, (err, isMatch) => {
            if (err) throw err;

            if (isMatch) {
                res.send('Login successful!');
            } else {
                res.status(400).send('Invalid password');
            }
        });
    });
});

// Forgot Password Route
app.post('/forgot_password.php', (req, res) => {
    const { email } = req.body;

    const query = 'SELECT * FROM users WHERE email = ?';
    db.query(query, [email], (err, results) => {
        if (err) throw err;

        if (results.length === 0) {
            return res.status(400).send('Email not found');
        }

        // Implement actual password reset logic (send email, etc.)
        res.send('Password reset request submitted. Please check your email.');
    });
});

// Start the server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});
