// add event listener to sign-up link
document.getElementById('signup-link').addEventListener('click', function() {
    // toggle sign-up form visibility
    document.querySelector('.signup-form').style.display = 'block';
});